README.md

# Library Management System

This is a book mangement system made in C. It allows you to store and organize each Book by name, author, pages, and price.

# Contributing

Feel Free to use and update this repo. I worked on this to expand my understanding on programming in C.

Enjoy!!!
